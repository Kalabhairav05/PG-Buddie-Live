// ============================================================
// STUDENT DASHBOARD
// ============================================================

const API_BASE_URL = "http://localhost:5000";


// ============================================================
// LOAD STUDENT INFORMATION
// ============================================================

const studentNameSpan =
    document.getElementById("studentName");

const storedUser =
    localStorage.getItem("pgBuddieUser");

let currentUser = null;

try {
    currentUser = storedUser
        ? JSON.parse(storedUser)
        : null;
} catch (error) {
    console.error(
        "Unable to read stored user:",
        error
    );
}


// Display the real name returned by the backend.

if (
    studentNameSpan &&
    currentUser &&
    currentUser.name
) {
    studentNameSpan.textContent =
        currentUser.name;
} else if (studentNameSpan) {
    studentNameSpan.textContent =
        "Student";
}


// ============================================================
// LOGOUT
// ============================================================

const logoutBtn =
    document.getElementById("logoutBtn");

if (logoutBtn) {

    logoutBtn.addEventListener(
        "click",
        (event) => {

            event.preventDefault();

            /*
              Remove the actual authentication
              information used by PG Buddie.
            */

            localStorage.removeItem(
                "pgBuddieToken"
            );

            localStorage.removeItem(
                "pgBuddieUser"
            );


            /*
              Do NOT use:

                studentEmail
                selectedPG

              as authentication anymore.
            */


            window.location.href =
                "login.html";
        }
    );
}


// ============================================================
// OPTIONAL: BOOK NOW HANDLING
// ============================================================
//
// The old implementation stored:
//
//     selectedPG
//
// in localStorage.
//
// We are intentionally NOT restoring that code.
//
// Real bookings now go through:
//
//     POST /api/bookings
//
// and are stored in MongoDB.
//
// The actual booking UI will be connected
// to the backend separately.
// ============================================================